ABOUT THIS FILE:
----------------
	This document describes version 2.5c of TapWAV,  a small Windows(R) 
utility which converts TAP files into audio files to save them on C64 tapes.


INFO & CREDITS:
---------------
	TapWAV 2.5c, 11 Feb 2004	

	Coding: Luigi Di Fraia
	Windows Coding Assistance: Marco Era
	Technical Assistance: Fabrizio Gennari, Mike


HOW TO USE:
-----------
	TapWAV converts "clean" TAP files (just Version 1) into uncompressed
PCM WAV files. To save them on tapes an audio recorder is needed together
with a soundcard.
	There are 5 sampling options:

	- Sample Freq: to set the sampling frequency of the generated 
	  audio file; 3 values are possible, with a default selection of
	  44100 Hz. Do not change it if you do not meet aliasing warnings
	  (see ahead).

	- Waveform: to set the sample shape; 2 values are possible, with 
	  a default "Square" selection. "Smoothed" solves some overrange
	  problems occurring at a high sampling frequency around waveform 
	  edges.

	- Reverse samples: some soundcards seem to reverse samples during 
	  audio files playing. In order to obtain working tapes you need 
	  to select this option if your soundcard reverts samples.

	- Use NTSC timings: MTap from Markus Brenner supports Tap making 
	  at NTSC machines clock frequency, so this option may be used for
	  Tap files generated with that option. It is suggested not to use 
	  this option.

	- Force long pulses being encoded as pauses: to produce a mute 
	  signal when a long pulse is found in the Tap file. This option 
	  is active by default.

	When opening a valid Version 1 Tap file, some infos are displayed and the 
save option is enabled so that WAV files can be produced using the chosen settings.

	In some cases TapWAV will signal the occurrence of "aliasing warnings". 
This means any square wave was syntetized using less than 10 samples (which is 
considered a safe value). This fact may produce aliasing problems during Digital 
to Analogic conversion (ie when playing the WAV on your PC). To avoid them, either 
use "clean" Tapes or increase the sampling frequency and retry.
	If you meet permanent warnings and you are sure about your tap file quality, 
contact me.


TIPS:
-----
	To record a WAV file to tape you need a tape recorder and a WAV player. 
The latter is easy to find (under Windows the MS Media Player itself is enough 
- anyway I would suggest to find one under MS-DOS and work under plain MS DOS), 
but for the recorder, you should note the following things:

	- disabling the audio options not needed will produce better signals on 
	  your soundcard output. This means, before recording disable:

		Line In, CD Audio, MIDI

	  and check if the soundcard output is still present. Thanks to Fabrizio 
	  Gennari for pointing this out;

	- a mono channel recorder would be better;
 
	- set the player volume on your PC at a medium level, then set the output 
	  volume of your recorder to zero (to avoid hearing the wav file while 
	  recording it) and a recording volume low (half volume should fit);
 
	- if your recorder has a VU Meter, you can adjust these starting settings 
	  to optimal ones during recording. Just be sure that when data is sent 
	  (keep watching for 20-30 seconds about) your VU Meter indicates at 
	  least -3db and doesn't exceed +3db about. In case you don't read such 
	  a range, adjust your player volume and when ok, restart recording from 
	  the beginning.


LINKS:
------
	Here there are some links I suggest to visit:

AUDIOTAP, LINKS AND USEFUL INFORMATIONS AT:
	Fabrizio Gennari's WAV-PRG and Audiotap page
	http://wav-prg.sourceforge.net/index.html

FINAL TAP, THE ULTIMATE TAP CLEANING TOOL AT:
	Stewart Wilson's Handcrafted Emulation Tools
	http://www.coder.pwp.blueyonder.co.uk/index.htm

CLEAN TAP FILES AND MORE AT:
	Tom Roger Skauen's "The Ultimate C64 Tape Page"
	http://tapes.c64.no/

TRANSFER TOOLS:
	Funet.fi
	http://www.funet.fi/pub/cbm/crossplatform/transfer/datassette/


CONTACT POINTS:
---------------
	TapWAV is currently available at:

	http://digilander.libero.it/tcengineer/c64/index.htm

	You can contact me for bugs, suggestion or anything else about this file 
or this program, at:

	armaeth@libero.it

	Good Work.

	Luigi Di Fraia.