WAV-PRG 4.1
-----------
This archive contains:
* wavprg.exe, converts Commodore tapes into T64, PRG and P00
  Distributed under the GNU General Public License, see LICENSE.TXT
* audiotap.dll, library that allows to read and write TAP files
  Distributed under the GNU Lesser General Public License, see
  LESSER-LICENSE.TXT

For further information, consult the web site http://wav-prg.sourceforge.net