FT 2.7 b2


New formats in this release...


 - Flashload
 - Virgin Tape
 - Hi-Tec Tape
 - Tengen/Domark/Imageworks Tape (F1)
 - Ocean New Tape F1 (T1-T2)
 - Ocean New Tape F2
 - Snakeload 5.0 (T1-T2)
 - Snakeload 5.1
 - Atlantis Tape
 - Palace Tape F1
 - Palace Tape F2
 - Enigma Variations Tape

--------------------------------------------------------------
Known Issues...

You tell me ;)


I especially want to hear about...


 - TAP files that crash the program. (mail them if you can).

 - General observations that you think are bugs/problems/inaccuracies.

 - TAP files that cause mis-detections...

   As Final TAP expands it becomes ever more possible that one file-format
   gets mis-detected as another, I've resolved a great many of these situations
   (by Loader Recognition) but some taps are bound to slip through the net.

   Usually you can detect/clean to 100% by simply disabling the scanner that is 
   causing the problem, if you still have trouble then please tell me about it.



E-Mail : subc@operamail.com


--------------------------------------------------------------
Missing Scanners?...


 - Powerload.

   The formatting is too much of a pain in the ass, it provides checksums but only
   after a section of unmeasurable and unused data, even the loader itself can't
   verify the checksum.
   I was tempted to just have FT cut everything after the loaded data but thought
   better of it.


 - CRL.

   Too sloppy, prone to mis-detections.


 - Tengen/Domark/Imageworks (TDI) F2 (Used for multi-load files)

   I havn't yet found a reliable way to distinguish this format from TDI F1, 
   as soon as I do it'll be supported.
 

 - Gremlin/ Elder Gremlin/ Titus/ Ocean New 3 & 4...

   I havn't got around to looking at these yet but so few games use them (AFAIK) 
   its hardly worth the effort, especially when some of these look highly prone
   to cause mis-detections with other formats.

 





