#in your real path
cd /home/genmisc/software_output/liuhan/root/ca

#creat private key
openssl genrsa -aes256 \
      -out /home/genmisc/software_output/liuhan/root/ca/intermediate/private/www.example.com.key.pem 2048
      
chmod 400 /home/genmisc/software_output/liuhan/root/ca/intermediate/private/www.example.com.key.pem

#Use the private key to create a certificate signing request
#the Common Name cannot be the same as either your root or intermediate certificate.
cd /home/genmisc/software_output/liuhan/root/ca
openssl req -config /home/genmisc/software_output/liuhan/root/ca/intermediate/openssl.cnf \
      -key /home/genmisc/software_output/liuhan/root/ca/intermediate/private/www.example.com.key.pem \
      -new -sha256 -out /home/genmisc/software_output/liuhan/root/ca/intermediate/csr/www.example.com.csr.pem
      
#To create a certificate, use the intermediate CA to sign the CSR
cd /home/genmisc/software_output/liuhan/root/ca
openssl ca -config /home/genmisc/software_output/liuhan/root/ca/intermediate/openssl.cnf \
      -extensions server_cert -days 375 -notext -md sha256 \
      -in /home/genmisc/software_output/liuhan/root/ca/intermediate/csr/www.example.com.csr.pem \
      -out /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/www.example.com.cert.pem
chmod 444 intermediate/certs/www.example.com.cert.pem

#Verify the certificate -- The Issuer is the intermediate CA, The Subject refers to the certificate itself
openssl x509 -noout -text \
      -in /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/www.example.com.cert.pem
  
#Use the CA certificate chain file (ca-chain.cert.pem) to verify that the new certificate has a valid chain of trust.  
openssl verify -CAfile /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/ca-chain.cert.pem \
      /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/www.example.com.cert.pem

# convert certificate into DER format
openssl x509 -in /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/www.example.com.cert.pem \
-outform DER -out /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/TLS.example.cer

# convert private keys into DER format
openssl rsa -in /home/genmisc/software_output/liuhan/root/ca/intermediate/private/www.example.com.key.pem	\
-out /home/genmisc/software_output/liuhan/root/ca/intermediate/private/www.example.com.key.2048 -outform DER


#config infomation
Enter pass phrase for www.example.com.key.pem: secretpassword
You are about to be asked to enter information that will be incorporated
into your certificate request.
-----
Country Name (2 letter code) [XX]:US
State or Province Name []:California
Locality Name []:Mountain View
Organization Name []:Alice Ltd
Organizational Unit Name []:Alice Ltd Web Services
Common Name []:www.example.com
Email Address []:

#creat example.csr base on root config information       
openssl req -config /home/genmisc/software_output/liuhan/root/ca/openssl.cnf \
      -key /home/genmisc/software_output/liuhan/root/ca/intermediate/private/www.example.com.key.pem \
      -new -sha256 -out /home/genmisc/software_output/liuhan/root/ca/intermediate/csr/www.example.com.csr.pem